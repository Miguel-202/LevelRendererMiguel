var class_g_w_1_1_m_a_t_h_1_1_g_matrix =
[
    [ "Create", "class_g_w_1_1_m_a_t_h_1_1_g_matrix.html#a66e5434c607a549aa64a12537a8b2436", null ]
];