var struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction =
[
    [ "flags", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#a2e873492f6d3a749604ecca1da2177c1", null ],
    [ "layer", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#af41e2dcd60b0928352a973356a7d8f99", null ],
    [ "stencil", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#a62ff9b40a11ce674e7592462dbc6fcf9", null ],
    [ "t", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#a1b05d2c653e4f4fd44bdbd52e96f9f12", null ],
    [ "m", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#a2342648c50dc03a9ce611515970ff788", null ],
    [ "p", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#ae9110d54d4be2ee168fd1a642d163278", null ],
    [ "pad", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#a9ea71002c2d6815520c1960aa66d7c21", null ]
];