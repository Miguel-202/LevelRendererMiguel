var namespace_g_w_1_1_s_y_s_t_e_m =
[
    [ "GConcurrent", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_concurrent.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_concurrent" ],
    [ "GDaemon", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon" ],
    [ "GFile", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_file.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_file" ],
    [ "GLog", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log" ],
    [ "GWindow", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window" ],
    [ "UNIVERSAL_WINDOW_HANDLE", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e" ],
    [ "GWindowStyle", "group___system_defines.html#gad117891e556631f842625c348d36a071", [
      [ "WINDOWEDBORDERED", "group___system_defines.html#ggad117891e556631f842625c348d36a071ad5ac768d1ee51601f115153f0f5e039c", null ],
      [ "WINDOWEDBORDERLESS", "group___system_defines.html#ggad117891e556631f842625c348d36a071ab4a2425a77d8d66cb134170ecbaf4ddf", null ],
      [ "WINDOWEDLOCKED", "group___system_defines.html#ggad117891e556631f842625c348d36a071a5e5d2e082f1f91e46a31dbf0fa614eb7", null ],
      [ "FULLSCREENBORDERED", "group___system_defines.html#ggad117891e556631f842625c348d36a071a53f85450b2d0eb8b81333f2048b8adb5", null ],
      [ "FULLSCREENBORDERLESS", "group___system_defines.html#ggad117891e556631f842625c348d36a071a49d6a9c65f7c67a6d51afffe99f39555", null ],
      [ "MINIMIZED", "group___system_defines.html#ggad117891e556631f842625c348d36a071a43245b4788b59a22d5357a7146c06deb", null ]
    ] ]
];