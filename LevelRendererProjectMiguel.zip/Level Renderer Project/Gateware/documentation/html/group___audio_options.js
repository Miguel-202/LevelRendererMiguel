var group___audio_options =
[
    [ "GW::AUDIO::GATTENUATION", "group___audio_options.html#gaba9b072bf0fe2efe52a0c5a541d86faa", [
      [ "GW::AUDIO::LINEAR", "group___audio_options.html#ggaba9b072bf0fe2efe52a0c5a541d86faaab7d2ae426e11f047418bde85626c5252", null ]
    ] ]
];