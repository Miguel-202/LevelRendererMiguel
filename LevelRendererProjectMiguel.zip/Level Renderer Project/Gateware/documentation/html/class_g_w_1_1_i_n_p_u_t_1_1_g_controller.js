var class_g_w_1_1_i_n_p_u_t_1_1_g_controller =
[
    [ "EVENT_DATA", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a.html", "struct_g_w_1_1_i_n_p_u_t_1_1_g_controller_1_1_e_v_e_n_t___d_a_t_a" ],
    [ "Events", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a571539d6dfd766b0c1fb774286d24405", [
      [ "CONTROLLERBUTTONVALUECHANGED", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a571539d6dfd766b0c1fb774286d24405ac3e98949a16a1e02a918eca36e59377a", null ],
      [ "CONTROLLERAXISVALUECHANGED", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a571539d6dfd766b0c1fb774286d24405ad819e0300a72112dc8f2f6f4bc2630c8", null ],
      [ "CONTROLLERCONNECTED", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a571539d6dfd766b0c1fb774286d24405af8e5517c129659e2f5cf09a8ba6a92fd", null ],
      [ "CONTROLLERDISCONNECTED", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a571539d6dfd766b0c1fb774286d24405a7f2de8e6751bf519fe5d366ffbeececc", null ]
    ] ],
    [ "DeadZoneTypes", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a027e7c369bd0b37949d3df255986f760", [
      [ "DEADZONESQUARE", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a027e7c369bd0b37949d3df255986f760a6490fbad8d07efa691073120af3912a1", null ],
      [ "DEADZONECIRCLE", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a027e7c369bd0b37949d3df255986f760a67f94d7f1182134abbf4d8c6214fdaf4", null ]
    ] ],
    [ "Create", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a4828658b15d525473b626fbd37bac43c", null ],
    [ "GetState", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a6bf5110fc281e3deb3d07cd50a8d8404", null ],
    [ "IsConnected", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a9f5c5e889ea2cf8e17e64e4649c433b5", null ],
    [ "GetMaxIndex", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#ae4b140429727877ae4bac0152b67c0b5", null ],
    [ "GetNumConnected", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a0c7159012d5f6b1609ba2de4ea40899a", null ],
    [ "SetDeadZone", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a87572337406664233a299d857b5b8234", null ],
    [ "StartVibration", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a92b7fba8b7903679df2918e06bcef6d0", null ],
    [ "IsVibrating", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a0dbb35de56fb78910f1c882dabe4d186", null ],
    [ "StopVibration", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a75d342b3f664b5072f68f302bc2c208e", null ],
    [ "StopAllVibrations", "class_g_w_1_1_i_n_p_u_t_1_1_g_controller.html#a5717f7834cf31d639bb48d8c4d91e6a5", null ]
];