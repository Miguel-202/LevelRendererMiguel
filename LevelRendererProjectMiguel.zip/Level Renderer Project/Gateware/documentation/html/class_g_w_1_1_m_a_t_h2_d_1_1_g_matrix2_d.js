var class_g_w_1_1_m_a_t_h2_d_1_1_g_matrix2_d =
[
    [ "Create", "class_g_w_1_1_m_a_t_h2_d_1_1_g_matrix2_d.html#ab0d2a4f4835ed74e0c907a0c80022f54", null ]
];