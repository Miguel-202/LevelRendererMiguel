var group___system_defines =
[
    [ "GW::SYSTEM::UNIVERSAL_WINDOW_HANDLE", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html", [
      [ "window", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html#ae2626a78a5857d3da8698408088ac44a", null ],
      [ "display", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html#a4c21bc5627c779031ba3b4ba4a267734", null ]
    ] ],
    [ "GW::SYSTEM::GWindowStyle", "group___system_defines.html#gad117891e556631f842625c348d36a071", [
      [ "GW::SYSTEM::GWindowStyle::WINDOWEDBORDERED", "group___system_defines.html#ggad117891e556631f842625c348d36a071ad5ac768d1ee51601f115153f0f5e039c", null ],
      [ "GW::SYSTEM::GWindowStyle::WINDOWEDBORDERLESS", "group___system_defines.html#ggad117891e556631f842625c348d36a071ab4a2425a77d8d66cb134170ecbaf4ddf", null ],
      [ "GW::SYSTEM::GWindowStyle::WINDOWEDLOCKED", "group___system_defines.html#ggad117891e556631f842625c348d36a071a5e5d2e082f1f91e46a31dbf0fa614eb7", null ],
      [ "GW::SYSTEM::GWindowStyle::FULLSCREENBORDERED", "group___system_defines.html#ggad117891e556631f842625c348d36a071a53f85450b2d0eb8b81333f2048b8adb5", null ],
      [ "GW::SYSTEM::GWindowStyle::FULLSCREENBORDERLESS", "group___system_defines.html#ggad117891e556631f842625c348d36a071a49d6a9c65f7c67a6d51afffe99f39555", null ],
      [ "GW::SYSTEM::GWindowStyle::MINIMIZED", "group___system_defines.html#ggad117891e556631f842625c348d36a071a43245b4788b59a22d5357a7146c06deb", null ]
    ] ]
];