var searchData=
[
  ['eventflags_0',['eventFlags',['../struct_g_w_1_1_s_y_s_t_e_m_1_1_g_window_1_1_e_v_e_n_t___d_a_t_a.html#ae83c8e777941fc3fb901b96de4cb273d',1,'GW::SYSTEM::GWindow::EVENT_DATA']]],
  ['eventresult_1',['eventResult',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a.html#a13ba32e9a2df9e7a8587d32b2a2ef353',1,'GW::GRAPHICS::GVulkanSurface::EVENT_DATA']]]
];
