var searchData=
[
  ['nodata_0',['noData',['../struct_g_w_1_1_c_o_r_e_1_1_g_event_generator_1_1_e_v_e_n_t___d_a_t_a.html#a49e8f2451f7d866f09af625f23414fca',1,'GW::CORE::GEventGenerator::EVENT_DATA']]],
  ['numofchannels_1',['numOfChannels',['../struct_g_w_1_1_a_u_d_i_o_1_1_g_audio_1_1_e_v_e_n_t___d_a_t_a.html#a0a2cfb9389a84b9c7c25495a4517da3f',1,'GW::AUDIO::GAudio::EVENT_DATA']]]
];
