var class_g_w_1_1_a_u_d_i_o_1_1_g_music =
[
    [ "Create", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a64111a599d5620b6875114d21244175e", null ],
    [ "SetChannelVolumes", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a2f478018da407c7af36502eb18cdce69", null ],
    [ "SetVolume", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a3a98aa8e77a9db8e9d1c735c4740391d", null ],
    [ "Play", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a79a68db636b8b36b3a4ee8a0e8360590", null ],
    [ "Pause", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a79dbf66ba47ac16b523171a165e9a09a", null ],
    [ "Resume", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#ab1d4f55bd40314e4f7eecb8a5363bafc", null ],
    [ "Stop", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#ac71de54f276f08737f90610ebba6a878", null ],
    [ "GetSourceChannels", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a0fb92055092c252d88576759648544ca", null ],
    [ "GetOutputChannels", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a491bad78c180403f30419ce8d3b4d7a9", null ],
    [ "isPlaying", "class_g_w_1_1_a_u_d_i_o_1_1_g_music.html#a944865365f6e99374aacaaa037ff7f8b", null ]
];